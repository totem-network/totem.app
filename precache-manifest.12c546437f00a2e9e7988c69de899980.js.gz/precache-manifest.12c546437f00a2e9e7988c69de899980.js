self.__precacheManifest = [
  {
    "revision": "760ab053b3e9a8d8382bae6ba39e7444",
    "url": "images/cryptocurrency-icons/krb.svg"
  },
  {
    "revision": "e6222942b5f1a6c9888eb4bdd18a0763",
    "url": "images/cryptocurrency-icons/zrx.svg"
  },
  {
    "revision": "0a749f168e76426d0887ee08995c1d16",
    "url": "images/launcher-background.svg"
  },
  {
    "url": "launcher.075d95633c535c77d016.js"
  },
  {
    "url": "runtime~app.f51ac5b2d6f372cca9c6.js"
  },
  {
    "url": "side-nav.a8c0df9be0840c32e6ab.js"
  },
  {
    "url": "vendors~3box.1af6b03e08a2707bccf1.js"
  },
  {
    "url": "vendors~app.ddc799f160eca23c5327.js"
  },
  {
    "url": "windows.918c0d67708dfe7fbff4.js"
  },
  {
    "revision": "f2227e6e63aac20b2ad6ff530e5c0d84",
    "url": "index.html"
  },
  {
    "revision": "10bb853479bab7813b13572bb45f9785",
    "url": "images/logo.svg"
  },
  {
    "revision": "f9dd8316d4e8e2022cc6b0eff06b47f0",
    "url": "images/logo-flat.svg"
  },
  {
    "revision": "f7fe55efb6ab32e1c900513f413434f1",
    "url": "images/cryptocurrency-icons/lpt.svg"
  },
  {
    "revision": "e942b738de07700359748d40488ebdd5",
    "url": "images/cryptocurrency-icons/$pac.svg"
  },
  {
    "revision": "1aa1a205fcd737f695bbdf2ad609fb0c",
    "url": "images/cryptocurrency-icons/add.svg"
  },
  {
    "revision": "2efc44f82a7dd7279bf36f17e3179362",
    "url": "images/cryptocurrency-icons/actn.svg"
  },
  {
    "revision": "ef6bb3b2bf90896043e0055d918edc0f",
    "url": "images/cryptocurrency-icons/ada.svg"
  },
  {
    "revision": "ce403f974ed934054101defaabd31d42",
    "url": "images/cryptocurrency-icons/ae.svg"
  },
  {
    "revision": "e85885414eb9b26a9bdbbccf9d91c0b6",
    "url": "images/cryptocurrency-icons/adx.svg"
  },
  {
    "revision": "503a11e74b848cede5f6676e0f00204d",
    "url": "images/cryptocurrency-icons/aeon.svg"
  },
  {
    "revision": "4d354b73b750edc3d735232818dfb22f",
    "url": "images/cryptocurrency-icons/agrs.svg"
  },
  {
    "revision": "9f37c8d4a65e4bea64240f9a017301ca",
    "url": "images/cryptocurrency-icons/aion.svg"
  },
  {
    "revision": "e1f0fc0d732b0e3f0c263c94f96cf6f1",
    "url": "images/cryptocurrency-icons/amb.svg"
  },
  {
    "revision": "10350c12966ed43372d3d8f326306dd9",
    "url": "images/cryptocurrency-icons/ant.svg"
  },
  {
    "revision": "c14237c895ffabba7be7cbd57caab4c1",
    "url": "images/cryptocurrency-icons/agi.svg"
  },
  {
    "revision": "7796d85ad162b17759cea1d70c55ec5c",
    "url": "images/cryptocurrency-icons/amp.svg"
  },
  {
    "revision": "65be10f51c82a1086b43b76d231e13ab",
    "url": "images/cryptocurrency-icons/apex.svg"
  },
  {
    "revision": "496e1c442f2d0456f4af13e6457e07fc",
    "url": "images/cryptocurrency-icons/appc.svg"
  },
  {
    "revision": "24d5fe26573505c2b98fdb44c1fe92b3",
    "url": "images/cryptocurrency-icons/ardr.svg"
  },
  {
    "revision": "985bceabcc4dd3c03fb1112d2e266644",
    "url": "images/cryptocurrency-icons/arg.svg"
  },
  {
    "revision": "ff584c23daf86356b8c1fc4245bcf168",
    "url": "images/cryptocurrency-icons/ark.svg"
  },
  {
    "revision": "63b990fae4fba6b338aa5fb961dde3f3",
    "url": "images/cryptocurrency-icons/arn.svg"
  },
  {
    "revision": "4a2724349501b7409917d547aa407c56",
    "url": "images/cryptocurrency-icons/ary.svg"
  },
  {
    "revision": "81807efb16ec077874014722f4c62532",
    "url": "images/cryptocurrency-icons/ast.svg"
  },
  {
    "revision": "c45155e81f489c446179a6bf48c74eca",
    "url": "images/cryptocurrency-icons/atm.svg"
  },
  {
    "revision": "1033abcec7eded69edf3840d25c34b40",
    "url": "images/cryptocurrency-icons/audr.svg"
  },
  {
    "revision": "abf956ab291c453bfd98f570dee5437c",
    "url": "images/cryptocurrency-icons/auto.svg"
  },
  {
    "revision": "7da25d5b264e0fdc35c6b71cdc0fa3be",
    "url": "images/cryptocurrency-icons/bab.svg"
  },
  {
    "revision": "3543f3d1154362f8a2d9f86c5c0bd052",
    "url": "images/cryptocurrency-icons/aywa.svg"
  },
  {
    "revision": "0092359ba674879a0bb8084163471408",
    "url": "images/cryptocurrency-icons/bat.svg"
  },
  {
    "revision": "20a3d7a69d9cd079d702fa32166a0488",
    "url": "images/cryptocurrency-icons/bay.svg"
  },
  {
    "revision": "d4c3b3718cdabcd5836778a962c9e588",
    "url": "images/cryptocurrency-icons/bcbc.svg"
  },
  {
    "revision": "3ee6b8e3b3dd0354cbe12f297e301147",
    "url": "images/cryptocurrency-icons/bcc.svg"
  },
  {
    "revision": "08c61723daf21c25cd9ccbb7cbd5320c",
    "url": "images/cryptocurrency-icons/bcd.svg"
  },
  {
    "revision": "dd0affc60619a1b2adcbd617def0909f",
    "url": "images/cryptocurrency-icons/bch.svg"
  },
  {
    "revision": "3a79c228b4826471941c6edadfb214f3",
    "url": "images/cryptocurrency-icons/bcn.svg"
  },
  {
    "revision": "c8419c35880c7028ec2797f72e93bda0",
    "url": "images/cryptocurrency-icons/bela.svg"
  },
  {
    "revision": "4b34a88cb0c706136be3136de74eb75b",
    "url": "images/cryptocurrency-icons/bdl.svg"
  },
  {
    "revision": "16bb8fe800a76a9e941fbda68228e697",
    "url": "images/cryptocurrency-icons/bco.svg"
  },
  {
    "revision": "4a7ac2c67992600fe0b91496726168e7",
    "url": "images/cryptocurrency-icons/bix.svg"
  },
  {
    "revision": "b51eee16c9f09d80d521818513dda852",
    "url": "images/cryptocurrency-icons/bcpt.svg"
  },
  {
    "revision": "187f2770ce5ac1fc25ee480db9dac96f",
    "url": "images/cryptocurrency-icons/blcn.svg"
  },
  {
    "revision": "b22e7b37cfa00ac64e5efe3a13843d21",
    "url": "images/cryptocurrency-icons/block.svg"
  },
  {
    "revision": "c2d112374587cb2974782acd7cdd9b63",
    "url": "images/cryptocurrency-icons/blk.svg"
  },
  {
    "revision": "ad2a715f07a3180bbae0e906b587ecf6",
    "url": "images/cryptocurrency-icons/bnb.svg"
  },
  {
    "revision": "3992e92d825b445d73393506059e567f",
    "url": "images/cryptocurrency-icons/blz.svg"
  },
  {
    "revision": "8eb0fa81ba3b96030943499b6a9b8b6f",
    "url": "images/cryptocurrency-icons/bnt.svg"
  },
  {
    "revision": "70632e44a57ff4298b59a83fee674624",
    "url": "images/cryptocurrency-icons/bnty.svg"
  },
  {
    "revision": "82134c9fce68233b457ca7698b7b84ac",
    "url": "images/cryptocurrency-icons/bos.svg"
  },
  {
    "revision": "0c7f429f801346687779679af6bc3ae4",
    "url": "images/cryptocurrency-icons/booty.svg"
  },
  {
    "revision": "30f0d823a4edb4bc3ba2f6bea9ef5fb9",
    "url": "images/cryptocurrency-icons/bq.svg"
  },
  {
    "revision": "16c769f044d7ee17f0ef82a0af7ed490",
    "url": "images/cryptocurrency-icons/brd.svg"
  },
  {
    "revision": "7106d8f1990cefcef5a893ca5dff288d",
    "url": "images/cryptocurrency-icons/bpt.svg"
  },
  {
    "revision": "37f08fc69638bff7aacd9513d1f5f6ca",
    "url": "images/cryptocurrency-icons/bsd.svg"
  },
  {
    "revision": "18c5b89ad92c52c30022b8a55f073d92",
    "url": "images/cryptocurrency-icons/btc.svg"
  },
  {
    "revision": "429092c1d1af63e6a37bbee64b62ad8a",
    "url": "images/cryptocurrency-icons/btcd.svg"
  },
  {
    "revision": "e99813b08cac0d5bdb34be4d8347581a",
    "url": "images/cryptocurrency-icons/btch.svg"
  },
  {
    "revision": "c3283410ff12520616a72431e0b7cdff",
    "url": "images/cryptocurrency-icons/bsv.svg"
  },
  {
    "revision": "730004d8dbdc11b24fb604e8818d8dcc",
    "url": "images/cryptocurrency-icons/btcp.svg"
  },
  {
    "revision": "4b13a4b5432ac2a58e2204438aba2788",
    "url": "images/cryptocurrency-icons/btcz.svg"
  },
  {
    "revision": "9220adfd9c4d65f4033dc3e8a9460ac4",
    "url": "images/cryptocurrency-icons/btdx.svg"
  },
  {
    "revision": "46ae210202d0dd34b3f7e5e86ba22046",
    "url": "images/cryptocurrency-icons/btg.svg"
  },
  {
    "revision": "566344d5575eabd3b8d69942b4800480",
    "url": "images/cryptocurrency-icons/bts.svg"
  },
  {
    "revision": "463e6400b8f926674e4c3dc4885eec7e",
    "url": "images/cryptocurrency-icons/btm.svg"
  },
  {
    "revision": "3eb7f512f9bb0441ec80a03cff0ff54e",
    "url": "images/cryptocurrency-icons/btx.svg"
  },
  {
    "revision": "8ed971372aebcec3a7f1e274f4ab54bc",
    "url": "images/cryptocurrency-icons/call.svg"
  },
  {
    "revision": "eda2b48da9f30ba37f5f40dcbba314f7",
    "url": "images/cryptocurrency-icons/cc.svg"
  },
  {
    "revision": "4f68cab820fa9407c136044dc300fa34",
    "url": "images/cryptocurrency-icons/burst.svg"
  },
  {
    "revision": "696bc9682def3b44585de5ec3861933d",
    "url": "images/cryptocurrency-icons/cdt.svg"
  },
  {
    "revision": "434b88648410391a9520442bf324de2a",
    "url": "images/cryptocurrency-icons/cenz.svg"
  },
  {
    "revision": "f54db1e54c70b179858ba4596f907372",
    "url": "images/cryptocurrency-icons/chain.svg"
  },
  {
    "revision": "d0c83d2dc8ed8e31410fe26e27212475",
    "url": "images/cryptocurrency-icons/cdn.svg"
  },
  {
    "revision": "66852cf04bc3b323f7b757a8c41c748b",
    "url": "images/cryptocurrency-icons/chat.svg"
  },
  {
    "revision": "45e67c2748fe6984f7aee708600dbb74",
    "url": "images/cryptocurrency-icons/chips.svg"
  },
  {
    "revision": "0695731df32a8c02cf28fc9fdc7f3539",
    "url": "images/cryptocurrency-icons/cix.svg"
  },
  {
    "revision": "e4c2be42998eb28de00d848ffe693878",
    "url": "images/cryptocurrency-icons/clam.svg"
  },
  {
    "revision": "c97daf9765f1a96aaf69debcd9dda374",
    "url": "images/cryptocurrency-icons/cloak.svg"
  },
  {
    "revision": "6abb9a3f2950ab7333d3e0e821ab8ec5",
    "url": "images/cryptocurrency-icons/cmm.svg"
  },
  {
    "revision": "59f87eeb552713addd811c5e46dea5ee",
    "url": "images/cryptocurrency-icons/cnd.svg"
  },
  {
    "revision": "7f7b6cc9a45e34cc13b7f20cc28098f0",
    "url": "images/cryptocurrency-icons/cob.svg"
  },
  {
    "revision": "3394aa44795ecf3b224448f8c919ce10",
    "url": "images/cryptocurrency-icons/cnx.svg"
  },
  {
    "revision": "a31d068282a4f00d6b8d92d50033b2f6",
    "url": "images/cryptocurrency-icons/cmt.svg"
  },
  {
    "revision": "be08f5660ee4a87c6435030eea4946b3",
    "url": "images/cryptocurrency-icons/colx.svg"
  },
  {
    "revision": "d2eaa6db4393410afa361ecc2bb1e5de",
    "url": "images/cryptocurrency-icons/cred.svg"
  },
  {
    "revision": "68384c8b22cb935c6a13798c2081b572",
    "url": "images/cryptocurrency-icons/cny.svg"
  },
  {
    "revision": "e3f79173c619d839a63fb92b3cd0a394",
    "url": "images/cryptocurrency-icons/coqui.svg"
  },
  {
    "revision": "e523077b2de5f745ed91e77c3c5ed4d1",
    "url": "images/cryptocurrency-icons/crpt.svg"
  },
  {
    "revision": "1b7f319e6e3e7c257ca0451dd8609e96",
    "url": "images/cryptocurrency-icons/crw.svg"
  },
  {
    "revision": "31f54fdfba819624f9ae9ae5eb5ec600",
    "url": "images/cryptocurrency-icons/cs.svg"
  },
  {
    "revision": "b92867308e8ec8bb0084a51836a0e756",
    "url": "images/cryptocurrency-icons/ctxc.svg"
  },
  {
    "revision": "2a4cf23353e7b8c4b9e6e3a67c49be40",
    "url": "images/cryptocurrency-icons/ctr.svg"
  },
  {
    "revision": "e988ce2daff8cacc7bc90889c72a7e20",
    "url": "images/cryptocurrency-icons/cvc.svg"
  },
  {
    "revision": "f34e88aebc64c21a3c77e81e10c12b9e",
    "url": "images/cryptocurrency-icons/dash.svg"
  },
  {
    "revision": "21fc5de38f5e0c028430fb502faed18c",
    "url": "images/cryptocurrency-icons/dat.svg"
  },
  {
    "revision": "5ce63c16ce08c6581a6103637cd0fe2a",
    "url": "images/cryptocurrency-icons/data.svg"
  },
  {
    "revision": "9400c154fa8f337a47a422d0e607c443",
    "url": "images/cryptocurrency-icons/dbc.svg"
  },
  {
    "revision": "7f4970e42eca4f32b04fefea641bee37",
    "url": "images/cryptocurrency-icons/dcn.svg"
  },
  {
    "revision": "def23b9ea26a97202245af74b77e2d26",
    "url": "images/cryptocurrency-icons/deez.svg"
  },
  {
    "revision": "5649e7d63bb689b1b2b0271005b5fa49",
    "url": "images/cryptocurrency-icons/dcr.svg"
  },
  {
    "revision": "e0002a3ba8b93e7f2ac2cb9b026893cb",
    "url": "images/cryptocurrency-icons/dent.svg"
  },
  {
    "revision": "8ebf76b1379651d9df88907d82ab1b38",
    "url": "images/cryptocurrency-icons/zilla.svg"
  },
  {
    "revision": "80e1f2c96a61b0a8a2d527746e07d5cc",
    "url": "images/cryptocurrency-icons/2give.svg"
  },
  {
    "revision": "8da66c97bbfbd4b2ad4e66bb323e1505",
    "url": "images/cryptocurrency-icons/abt.svg"
  },
  {
    "revision": "24c92ebd0e2bc4b6d0f91cddcb474189",
    "url": "images/cryptocurrency-icons/zil.svg"
  },
  {
    "revision": "a90f314940d72e43a04e57ef719b5011",
    "url": "images/cryptocurrency-icons/zest.svg"
  },
  {
    "revision": "d59c7ec9e01b593b3907b79b7a135353",
    "url": "images/cryptocurrency-icons/zen.svg"
  },
  {
    "revision": "b9470017e480abcbd9aab8455f54ffe7",
    "url": "images/cryptocurrency-icons/zel.svg"
  },
  {
    "revision": "7583988ec170a14f24c2b06a131a46f5",
    "url": "images/cryptocurrency-icons/dew.svg"
  },
  {
    "revision": "4543dabed65d63bac2691e487a13e36f",
    "url": "images/cryptocurrency-icons/dgd.svg"
  },
  {
    "revision": "1db5b8cd9fee9773457a3184092ae482",
    "url": "images/cryptocurrency-icons/dnt.svg"
  },
  {
    "revision": "521c58954f14fbf0e76d71bd9095a864",
    "url": "images/cryptocurrency-icons/dgb.svg"
  },
  {
    "revision": "c16c8abdf9ef3740c1a88fc85a7ff3f3",
    "url": "images/cryptocurrency-icons/dnr.svg"
  },
  {
    "revision": "648a4166ef5650f000685e64af596d34",
    "url": "images/cryptocurrency-icons/dlt.svg"
  },
  {
    "revision": "12e1eebe016e5811468f14f4b99d66c3",
    "url": "images/cryptocurrency-icons/dock.svg"
  },
  {
    "revision": "c576bc6de068f0f053e7ed523af5a2a8",
    "url": "images/cryptocurrency-icons/doge.svg"
  },
  {
    "revision": "efaeff55f9fe0f079047441174c590e0",
    "url": "images/cryptocurrency-icons/drgn.svg"
  },
  {
    "revision": "fcbd3b968df2a8eee3b34f972f18d26c",
    "url": "images/cryptocurrency-icons/drop.svg"
  },
  {
    "revision": "497f028beb1e04d5450831c22d4586e1",
    "url": "images/cryptocurrency-icons/dta.svg"
  },
  {
    "revision": "97567d4d8985d0cfaa96deb75db09666",
    "url": "images/cryptocurrency-icons/dth.svg"
  },
  {
    "revision": "6e6e0e4711f455c923453169a3f701bd",
    "url": "images/cryptocurrency-icons/dtr.svg"
  },
  {
    "revision": "ac9688cd44620859a25df6f19b604bad",
    "url": "images/cryptocurrency-icons/ebst.svg"
  },
  {
    "revision": "136ee28b67ad22344335c034c1781667",
    "url": "images/cryptocurrency-icons/eca.svg"
  },
  {
    "revision": "03387e0f047d8629ed42d5ffcae495a4",
    "url": "images/cryptocurrency-icons/edg.svg"
  },
  {
    "revision": "8fae593f9991e794a922b29030582277",
    "url": "images/cryptocurrency-icons/edo.svg"
  },
  {
    "revision": "ed651643b950f168e832c7a3e45a37fb",
    "url": "images/cryptocurrency-icons/edoge.svg"
  },
  {
    "revision": "1c93a7ce852ce05cdef2a45f733cd6e8",
    "url": "images/cryptocurrency-icons/ela.svg"
  },
  {
    "revision": "34d722a92abdd689091fbb1e27f2ff17",
    "url": "images/cryptocurrency-icons/elf.svg"
  },
  {
    "revision": "cdab2fa1e02c92d2b7abd884c7377189",
    "url": "images/cryptocurrency-icons/elix.svg"
  },
  {
    "revision": "49108002748b9c358670b4c5a6c0ac9d",
    "url": "images/cryptocurrency-icons/ella.svg"
  },
  {
    "revision": "97e212235dead225d27846b6144c438c",
    "url": "images/cryptocurrency-icons/emc.svg"
  },
  {
    "revision": "b905dec63116e03939a0a9b0decc07f3",
    "url": "images/cryptocurrency-icons/emc2.svg"
  },
  {
    "revision": "dfdb1aad02038a759f43ef66fa08c534",
    "url": "images/cryptocurrency-icons/eng.svg"
  },
  {
    "revision": "a3807987db1e18a7a765d384b229e543",
    "url": "images/cryptocurrency-icons/enj.svg"
  },
  {
    "revision": "0fbd96fdc368f374001fb1272136c29c",
    "url": "images/cryptocurrency-icons/entrp.svg"
  },
  {
    "revision": "f61a843b90427e61733c23fea0688400",
    "url": "images/cryptocurrency-icons/eos.svg"
  },
  {
    "revision": "cff8a64f850f869dc3a98bbc6aa78894",
    "url": "images/cryptocurrency-icons/eqli.svg"
  },
  {
    "revision": "877473f699704a9e9551c2c3c356d919",
    "url": "images/cryptocurrency-icons/equa.svg"
  },
  {
    "revision": "c023b1aef6cd3e0651022a64b0a81da1",
    "url": "images/cryptocurrency-icons/etc.svg"
  },
  {
    "revision": "2263176fc2119a0b62e7fc5b4bae0d13",
    "url": "images/cryptocurrency-icons/eth.svg"
  },
  {
    "revision": "f9ef73f6f9695d2eff043eab4af1dcce",
    "url": "images/cryptocurrency-icons/ethos.svg"
  },
  {
    "revision": "dd98e9627bea2351d8fec9ceeebf6640",
    "url": "images/cryptocurrency-icons/etn.svg"
  },
  {
    "revision": "3f129966035fbe03750e11b269a994c4",
    "url": "images/cryptocurrency-icons/eur.svg"
  },
  {
    "revision": "c848066b0d987c33fc89081ab373d9aa",
    "url": "images/cryptocurrency-icons/etp.svg"
  },
  {
    "revision": "46e5740c0540a7a476369c546c1db552",
    "url": "images/cryptocurrency-icons/evx.svg"
  },
  {
    "revision": "b3666084ed07f909d263827536bd09ae",
    "url": "images/cryptocurrency-icons/exmo.svg"
  },
  {
    "revision": "aa4bd95274b6fad2509c3773a3c62ecf",
    "url": "images/cryptocurrency-icons/exp.svg"
  },
  {
    "revision": "8a9d2db6e41a5099dd8f494f45465e97",
    "url": "images/cryptocurrency-icons/fair.svg"
  },
  {
    "revision": "2e2de6baa820bb5d775120ab7b82487a",
    "url": "images/cryptocurrency-icons/fct.svg"
  },
  {
    "revision": "d0914b033293fa43c1e61658a71ea104",
    "url": "images/cryptocurrency-icons/fil.svg"
  },
  {
    "revision": "4ca1a052d098391f008f4d18501df0a5",
    "url": "images/cryptocurrency-icons/fjc.svg"
  },
  {
    "revision": "104f275c7ce9c91fd05418ce7b4923b3",
    "url": "images/cryptocurrency-icons/fldc.svg"
  },
  {
    "revision": "54854692c1fecb88a9a57ddf53611e40",
    "url": "images/cryptocurrency-icons/flo.svg"
  },
  {
    "revision": "05bd777ebc6511d413638d9191f91aa4",
    "url": "images/cryptocurrency-icons/fsn.svg"
  },
  {
    "revision": "8dc8bfd04bf80e3d67ea10f111b10711",
    "url": "images/cryptocurrency-icons/ftc.svg"
  },
  {
    "revision": "d77f0fed547bb0f05104cce9cb87b8c0",
    "url": "images/cryptocurrency-icons/fuel.svg"
  },
  {
    "revision": "a28f21a4d9fe72b32765804f2b5ae1b0",
    "url": "images/cryptocurrency-icons/fun.svg"
  },
  {
    "revision": "958efc51bb661143d275552edc9acd48",
    "url": "images/cryptocurrency-icons/game.svg"
  },
  {
    "revision": "8b012b1a336ecdcf51670c760751ea57",
    "url": "images/cryptocurrency-icons/gas.svg"
  },
  {
    "revision": "3a9dcc48c3c6fefbf70be35182c4c785",
    "url": "images/cryptocurrency-icons/gbp.svg"
  },
  {
    "revision": "a4ecdfe12d7bed9260958625083343ed",
    "url": "images/cryptocurrency-icons/gbx.svg"
  },
  {
    "revision": "f1f54c999a67a445fbc4f6c77b8ca7ec",
    "url": "images/cryptocurrency-icons/gbyte.svg"
  },
  {
    "revision": "288453391ae13c805cbd26cd4a551285",
    "url": "images/cryptocurrency-icons/generic.svg"
  },
  {
    "revision": "929eeb130390f733a337b4f41f6f5012",
    "url": "images/cryptocurrency-icons/glxt.svg"
  },
  {
    "revision": "3b57a54dca231cb8f51836f583ce72e8",
    "url": "images/cryptocurrency-icons/gmr.svg"
  },
  {
    "revision": "b0a904949c0d2b00e5bfecc4642bda83",
    "url": "images/cryptocurrency-icons/gnt.svg"
  },
  {
    "revision": "38e3408d47221f6b280fdb633d2f7ee6",
    "url": "images/cryptocurrency-icons/gno.svg"
  },
  {
    "revision": "c15f70f1ac266b82fee648f48b0ade34",
    "url": "images/cryptocurrency-icons/gold.svg"
  },
  {
    "revision": "9334509c5706389d123cb084b11390ae",
    "url": "images/cryptocurrency-icons/grc.svg"
  },
  {
    "revision": "58dd7b8713b4c5865da8f9e5bea12a35",
    "url": "images/cryptocurrency-icons/grs.svg"
  },
  {
    "revision": "3dba40d0b8b73f34af304178ecb94276",
    "url": "images/cryptocurrency-icons/gsc.svg"
  },
  {
    "revision": "688d436188ae5d0410cef6cd98d3fd09",
    "url": "images/cryptocurrency-icons/gto.svg"
  },
  {
    "revision": "0325dd420b7c9f5732bd17174d683adb",
    "url": "images/cryptocurrency-icons/gvt.svg"
  },
  {
    "revision": "783734cf78b781982fd5dee453d7c4e2",
    "url": "images/cryptocurrency-icons/gup.svg"
  },
  {
    "revision": "9a6c4709fb07cd13d061e3ae1ab6fc73",
    "url": "images/cryptocurrency-icons/gusd.svg"
  },
  {
    "revision": "56567ee1c6070804638438f5eec9380d",
    "url": "images/cryptocurrency-icons/gzr.svg"
  },
  {
    "revision": "d5e3e00b46faa365846ca816228ec3f0",
    "url": "images/cryptocurrency-icons/gxs.svg"
  },
  {
    "revision": "9501a43bc7d366b94331fed1b395f514",
    "url": "images/cryptocurrency-icons/hight.svg"
  },
  {
    "revision": "18ed5a955f087070c5711235920a90f2",
    "url": "images/cryptocurrency-icons/hodl.svg"
  },
  {
    "revision": "d5658e90933f88acf01c70c2e96671df",
    "url": "images/cryptocurrency-icons/hpb.svg"
  },
  {
    "revision": "54ae5ac3e20bc6da569959be2d394277",
    "url": "images/cryptocurrency-icons/hsr.svg"
  },
  {
    "revision": "e4d947d87e129820fa9072017fc33e9c",
    "url": "images/cryptocurrency-icons/ht.svg"
  },
  {
    "revision": "19bf9c0dc239464015caf743bd636268",
    "url": "images/cryptocurrency-icons/html.svg"
  },
  {
    "revision": "3db1b09cf07f6a38e1eef171da793a96",
    "url": "images/cryptocurrency-icons/hush.svg"
  },
  {
    "revision": "9501101d213d4fd530fa56a99abb20ca",
    "url": "images/cryptocurrency-icons/huc.svg"
  },
  {
    "revision": "08c521f8966b39c3161989c9c5fdcd1d",
    "url": "images/cryptocurrency-icons/icn.svg"
  },
  {
    "revision": "4562f55f73c8a55e438926dd177fdccc",
    "url": "images/cryptocurrency-icons/icx.svg"
  },
  {
    "revision": "a4f154ea65d5afe61adbf9856f2ea15a",
    "url": "images/cryptocurrency-icons/ignis.svg"
  },
  {
    "revision": "b7e2b97cf6bc8a311f1a6bf358c1be9e",
    "url": "images/cryptocurrency-icons/ink.svg"
  },
  {
    "revision": "cfe360bb682d7860608584cb7076e466",
    "url": "images/cryptocurrency-icons/ins.svg"
  },
  {
    "revision": "44ad218b4eb094b8ff2399d7af18a423",
    "url": "images/cryptocurrency-icons/ion.svg"
  },
  {
    "revision": "a07396cafc28dfab6688ca00e4f8f7c6",
    "url": "images/cryptocurrency-icons/iop.svg"
  },
  {
    "revision": "a53fcb89a139bf8b6709791920fee03e",
    "url": "images/cryptocurrency-icons/iost.svg"
  },
  {
    "revision": "2f46e6ab4f76d349426e4cc0bc0fe7c3",
    "url": "images/cryptocurrency-icons/iotx.svg"
  },
  {
    "revision": "80f2ce4eddb037c89eb337b8e9183bdb",
    "url": "images/cryptocurrency-icons/iq.svg"
  },
  {
    "revision": "aacb27dcb9ea3f2f80307ba6193ff743",
    "url": "images/cryptocurrency-icons/itc.svg"
  },
  {
    "revision": "ebbb0a26626f54c0fc5456d6c7fe15af",
    "url": "images/cryptocurrency-icons/jnt.svg"
  },
  {
    "revision": "1b91c2c446d8a0771de425ba2f819aed",
    "url": "images/cryptocurrency-icons/kcs.svg"
  },
  {
    "revision": "b36b561914d2a05495da6520acf15ad6",
    "url": "images/cryptocurrency-icons/kin.svg"
  },
  {
    "revision": "75fd6de7c9da422b85299ac48eed237e",
    "url": "images/cryptocurrency-icons/jpy.svg"
  },
  {
    "revision": "e6ae920b2e8e5d24fda771ca1a7e4a02",
    "url": "images/cryptocurrency-icons/kmd.svg"
  },
  {
    "revision": "059d8d176c103ef4641711709a3ce1d6",
    "url": "images/cryptocurrency-icons/knc.svg"
  },
  {
    "revision": "fcf75ce13cada1c6253cad376a99ced8",
    "url": "images/cryptocurrency-icons/zec.svg"
  },
  {
    "revision": "a5e35aaf99cf7a4071f33c677bd9b21a",
    "url": "images/cryptocurrency-icons/lbc.svg"
  },
  {
    "revision": "105e1064f4890e7415a15e3b205f5e32",
    "url": "images/cryptocurrency-icons/lend.svg"
  },
  {
    "revision": "76805a2be31e3a491bb5714f8cf63658",
    "url": "images/cryptocurrency-icons/link.svg"
  },
  {
    "revision": "53c2022093f56bb7035d73f643fe97da",
    "url": "images/cryptocurrency-icons/lkk.svg"
  },
  {
    "revision": "5be11be7fb20260f0c9cd48eda738cf1",
    "url": "images/cryptocurrency-icons/loom.svg"
  },
  {
    "revision": "9baa6a56a79c9c06c13a9cd254a60b7f",
    "url": "images/cryptocurrency-icons/act.svg"
  },
  {
    "revision": "6d7dfde4be5401641356e3c7c0ec7a6e",
    "url": "images/cryptocurrency-icons/lrc.svg"
  },
  {
    "revision": "456c0b95b12b3b2d59203fea83703f5c",
    "url": "images/cryptocurrency-icons/lsk.svg"
  },
  {
    "revision": "9578b740ac49bc7e80b280d56a768015",
    "url": "images/cryptocurrency-icons/lun.svg"
  },
  {
    "revision": "47be8565531fe3bc1efa8b81d5ffc384",
    "url": "images/cryptocurrency-icons/mana.svg"
  },
  {
    "revision": "72e6e51ee5f5c5b5744aa9e87afb24f5",
    "url": "images/cryptocurrency-icons/ltc.svg"
  },
  {
    "revision": "dd6b17473ca3162817929923812f6b26",
    "url": "images/cryptocurrency-icons/mcap.svg"
  },
  {
    "revision": "5f5defe4b1bad12f9d8aa67f56b1cb13",
    "url": "images/cryptocurrency-icons/maid.svg"
  },
  {
    "revision": "d0e180b6f427f54e883e0461d7c6a01f",
    "url": "images/cryptocurrency-icons/mco.svg"
  },
  {
    "revision": "8e970b805bc794802fa5557506d99cc0",
    "url": "images/cryptocurrency-icons/mda.svg"
  },
  {
    "revision": "7d42977c093a473df652c4a9fb5758eb",
    "url": "images/cryptocurrency-icons/mds.svg"
  },
  {
    "revision": "5d8e46fbeaedc880cbb59efb6375751e",
    "url": "images/cryptocurrency-icons/med.svg"
  },
  {
    "revision": "31e63e66f2ef4219f14f50548f83e183",
    "url": "images/cryptocurrency-icons/miota.svg"
  },
  {
    "revision": "3e3472d9ceebb076937af2487a852d9d",
    "url": "images/cryptocurrency-icons/mith.svg"
  },
  {
    "revision": "95ce7fd3dbab79fe059338d04a8db328",
    "url": "images/cryptocurrency-icons/mkr.svg"
  },
  {
    "revision": "a5f533230e59d98409dd509ed2e083aa",
    "url": "images/cryptocurrency-icons/mln.svg"
  },
  {
    "revision": "11c21033385fd2237b8394681e1946a8",
    "url": "images/cryptocurrency-icons/mnx.svg"
  },
  {
    "revision": "315e6009096f8f83f646faef6c766df7",
    "url": "images/cryptocurrency-icons/mnz.svg"
  },
  {
    "revision": "83a23070af163e89ff08f5b4340bc7f2",
    "url": "images/cryptocurrency-icons/moac.svg"
  },
  {
    "revision": "a4acf9637f60381f8812cc5d887d7e0b",
    "url": "images/cryptocurrency-icons/mona.svg"
  },
  {
    "revision": "a5c340e0a9cf56b7b7e28b42af54f9e6",
    "url": "images/cryptocurrency-icons/mod.svg"
  },
  {
    "revision": "4899941afe1590308d29d337c0727414",
    "url": "images/cryptocurrency-icons/msr.svg"
  },
  {
    "revision": "95ac6e252d06d364c75d411dbcb8a15e",
    "url": "images/cryptocurrency-icons/mth.svg"
  },
  {
    "revision": "7991043180e30577699ffa5f69fbc6c4",
    "url": "images/cryptocurrency-icons/mtl.svg"
  },
  {
    "revision": "e4e963c0ea8a45c1920a1257ba50fbd2",
    "url": "images/cryptocurrency-icons/music.svg"
  },
  {
    "revision": "14bdee58744c118c07d4e75f08c2ab4a",
    "url": "images/cryptocurrency-icons/mzc.svg"
  },
  {
    "revision": "3502d76477bf62769e15e60876b7897d",
    "url": "images/cryptocurrency-icons/nano.svg"
  },
  {
    "revision": "5b2c19b2348a80505b43ea2f3a90c232",
    "url": "images/cryptocurrency-icons/nas.svg"
  },
  {
    "revision": "b95f67fcf7d869ceb4fc0ad613aea1b4",
    "url": "images/cryptocurrency-icons/nav.svg"
  },
  {
    "revision": "f8b72f2d9f0a31fa24422694a43506ee",
    "url": "images/cryptocurrency-icons/ncash.svg"
  },
  {
    "revision": "35cf2d7946e9c0f78280e8623512369f",
    "url": "images/cryptocurrency-icons/nebl.svg"
  },
  {
    "revision": "952abf74c0be110f7a5052c52e14dd98",
    "url": "images/cryptocurrency-icons/ndz.svg"
  },
  {
    "revision": "8b012b1a336ecdcf51670c760751ea57",
    "url": "images/cryptocurrency-icons/neo.svg"
  },
  {
    "revision": "d6d58f91c90a5683e2de6ca0224a0ef5",
    "url": "images/cryptocurrency-icons/neu.svg"
  },
  {
    "revision": "d7fb2ddc9fa08d10169327038169ec69",
    "url": "images/cryptocurrency-icons/neos.svg"
  },
  {
    "revision": "fe141d3401d44fa3aa9c14bfc915a00c",
    "url": "images/cryptocurrency-icons/ngc.svg"
  },
  {
    "revision": "092deef050402e0f65d4f68648153662",
    "url": "images/cryptocurrency-icons/nexo.svg"
  },
  {
    "revision": "30862d03ddb0924d6792c5e20aafef04",
    "url": "images/cryptocurrency-icons/nio.svg"
  },
  {
    "revision": "443d5bdd8ff2efcfadae0fa00444df50",
    "url": "images/cryptocurrency-icons/nlc2.svg"
  },
  {
    "revision": "88ad9a7e599c892e65427c7087b28a02",
    "url": "images/cryptocurrency-icons/nlg.svg"
  },
  {
    "revision": "5b5de15f8674299bb97ff7fae4060f5c",
    "url": "images/cryptocurrency-icons/nmc.svg"
  },
  {
    "revision": "a2e7032e5f0c420ed39f2975361c70e3",
    "url": "images/cryptocurrency-icons/npxs.svg"
  },
  {
    "revision": "c470f3c7561d79313d275e62d04d16c7",
    "url": "images/cryptocurrency-icons/nuls.svg"
  },
  {
    "revision": "f5e29971dfbfe1041fe55f041b0ce093",
    "url": "images/cryptocurrency-icons/nxs.svg"
  },
  {
    "revision": "b6dd14aa93364dcd349a26619c2dafe3",
    "url": "images/cryptocurrency-icons/nxt.svg"
  },
  {
    "revision": "d0f4def67d4c933ca1c424e071f06be8",
    "url": "images/cryptocurrency-icons/ok.svg"
  },
  {
    "revision": "9f49c55e06e0e58aafb8d5e706d54fe6",
    "url": "images/cryptocurrency-icons/oax.svg"
  },
  {
    "revision": "cc25dacb398993bbb6f90e764c2db7ee",
    "url": "images/cryptocurrency-icons/omg.svg"
  },
  {
    "revision": "79b743bc16dd2cfb559b95492e3ac500",
    "url": "images/cryptocurrency-icons/omni.svg"
  },
  {
    "revision": "18e9b6b4a9dc8014de8b374313d9cfa3",
    "url": "images/cryptocurrency-icons/ong.svg"
  },
  {
    "revision": "22a13e38767d5db07e6a06344af6a1af",
    "url": "images/cryptocurrency-icons/ont.svg"
  },
  {
    "revision": "676bad3f16de9ecf553e350d210ed4d1",
    "url": "images/cryptocurrency-icons/oot.svg"
  },
  {
    "revision": "232459a8a95c71a783647ab14854b226",
    "url": "images/cryptocurrency-icons/ost.svg"
  },
  {
    "revision": "3750ecd9399824d37381817ca6573def",
    "url": "images/cryptocurrency-icons/part.svg"
  },
  {
    "revision": "5a0f09ff3a44dd0e40e119c8298531d3",
    "url": "images/cryptocurrency-icons/ox.svg"
  },
  {
    "revision": "4c2cb427e5057210884ce81dd071f873",
    "url": "images/cryptocurrency-icons/pasc.svg"
  },
  {
    "revision": "12388b859b6b5afd5519ff78af4a92d1",
    "url": "images/cryptocurrency-icons/pasl.svg"
  },
  {
    "revision": "eb0749fc07ed71e641baf789f51f4f8c",
    "url": "images/cryptocurrency-icons/pax.svg"
  },
  {
    "revision": "2ab279c342fc3857947af480ad3ab6d2",
    "url": "images/cryptocurrency-icons/pay.svg"
  },
  {
    "revision": "df7b82a689706ca22a35be8a6421ee28",
    "url": "images/cryptocurrency-icons/payx.svg"
  },
  {
    "revision": "2b71e92835ec24788b76540d95bb8a3d",
    "url": "images/cryptocurrency-icons/pink.svg"
  },
  {
    "revision": "b8ae0a5dfec2174f95e3eea52cca2d14",
    "url": "images/cryptocurrency-icons/pirl.svg"
  },
  {
    "revision": "1aa786a5b9ffde04a6dada003515f717",
    "url": "images/cryptocurrency-icons/pivx.svg"
  },
  {
    "revision": "8e040aa152eb16cc15fe9d13ca015de7",
    "url": "images/cryptocurrency-icons/plr.svg"
  },
  {
    "revision": "3ecf6d9fd12d7fa6a827d48542409aea",
    "url": "images/cryptocurrency-icons/poa.svg"
  },
  {
    "revision": "f9936ca43d9f7bbf66b65a7c233d6af0",
    "url": "images/cryptocurrency-icons/poe.svg"
  },
  {
    "revision": "d145d808918de6b90f4a79df4769e963",
    "url": "images/cryptocurrency-icons/polis.svg"
  },
  {
    "revision": "e60050319fd2770a439a722790e2ade6",
    "url": "images/cryptocurrency-icons/poly.svg"
  },
  {
    "revision": "0f29d6c7ac5d34d1fb0f13fa55d387b0",
    "url": "images/cryptocurrency-icons/pot.svg"
  },
  {
    "revision": "01223899f5416952b9c1ad2bd61360dd",
    "url": "images/cryptocurrency-icons/powr.svg"
  },
  {
    "revision": "3252293cd06a256772022961ccbb9716",
    "url": "images/cryptocurrency-icons/ppc.svg"
  },
  {
    "revision": "e6b3f22a4ba1cf3d7650432d64157d0d",
    "url": "images/cryptocurrency-icons/ppp.svg"
  },
  {
    "revision": "457e0ec3d100ed6e1b9b14e388d7c2be",
    "url": "images/cryptocurrency-icons/ppt.svg"
  },
  {
    "revision": "5804f1a8c8cfa48dcbf4533916f43ff3",
    "url": "images/cryptocurrency-icons/prl.svg"
  },
  {
    "revision": "6454ea6b2504add1e8a7f8a15607b48c",
    "url": "images/cryptocurrency-icons/pungo.svg"
  },
  {
    "revision": "1ff92efee7cf684d6396a2a6c47b8751",
    "url": "images/cryptocurrency-icons/pura.svg"
  },
  {
    "revision": "cdef11ec2d96f7ae951b09fcf527ea50",
    "url": "images/cryptocurrency-icons/qash.svg"
  },
  {
    "revision": "51a11f440d7e929b7f54631e909b3226",
    "url": "images/cryptocurrency-icons/qiwi.svg"
  },
  {
    "revision": "9daf9dc138b22bb61642cf509d1b1ef0",
    "url": "images/cryptocurrency-icons/qlc.svg"
  },
  {
    "revision": "4f64b0d076a2140afd7bf2de100fb9e8",
    "url": "images/cryptocurrency-icons/qrl.svg"
  },
  {
    "revision": "da28b0166e185590b22e7aa1ca5de13c",
    "url": "images/cryptocurrency-icons/qsp.svg"
  },
  {
    "revision": "6a305ec1587a5b58adbdc447f1e7542a",
    "url": "images/cryptocurrency-icons/qtum.svg"
  },
  {
    "revision": "b5c30ba38c40a5d4bd5f854c0c6415a2",
    "url": "images/cryptocurrency-icons/r.svg"
  },
  {
    "revision": "564001783690b6edbb58626de2b927cf",
    "url": "images/cryptocurrency-icons/rads.svg"
  },
  {
    "revision": "6a05f3a9bb863a59c51afadcb9a7ce69",
    "url": "images/cryptocurrency-icons/rap.svg"
  },
  {
    "revision": "8d92ecb36be03ffea4b46a25a2a53c51",
    "url": "images/cryptocurrency-icons/rcn.svg"
  },
  {
    "revision": "f71b5ea9176bc1a45ac29a7904aaaed5",
    "url": "images/cryptocurrency-icons/rdd.svg"
  },
  {
    "revision": "af64669998c378f8399f6569c9b58fe7",
    "url": "images/cryptocurrency-icons/rdn.svg"
  },
  {
    "revision": "373fab2854a7bd5bafe4f94b1d153c0b",
    "url": "images/cryptocurrency-icons/rep.svg"
  },
  {
    "revision": "b706bb3c533fcec5bf01a3c56ec535b9",
    "url": "images/cryptocurrency-icons/req.svg"
  },
  {
    "revision": "4ad974a48f849b0b83208667669c783d",
    "url": "images/cryptocurrency-icons/rhoc.svg"
  },
  {
    "revision": "fd1ebe9fcb4d07e96f7042746fd36c39",
    "url": "images/cryptocurrency-icons/ric.svg"
  },
  {
    "revision": "116d6dc836dc468e0d9726fc187448fc",
    "url": "images/cryptocurrency-icons/rlc.svg"
  },
  {
    "revision": "a5b176c1d2854263683cf50244b7308d",
    "url": "images/cryptocurrency-icons/rise.svg"
  },
  {
    "revision": "f528eeaff6e19d06e55cdd47fa6e9309",
    "url": "images/cryptocurrency-icons/rpx.svg"
  },
  {
    "revision": "f4d200ee9a36848adddd3aeba2d229f9",
    "url": "images/cryptocurrency-icons/rub.svg"
  },
  {
    "revision": "b0921ab3584586d02b9ee82321be321d",
    "url": "images/cryptocurrency-icons/rvn.svg"
  },
  {
    "revision": "be9e4f466877be0bba2261905d6faf3a",
    "url": "images/cryptocurrency-icons/safe.svg"
  },
  {
    "revision": "7347ef5465d1e326ed823f61061d4b64",
    "url": "images/cryptocurrency-icons/ryo.svg"
  },
  {
    "revision": "95b9df83fceaaed7467bb30353a95de6",
    "url": "images/cryptocurrency-icons/salt.svg"
  },
  {
    "revision": "54e90000dc809dafa33ca791cdd85e19",
    "url": "images/cryptocurrency-icons/san.svg"
  },
  {
    "revision": "e1a29642d18fa0f1ed3888094fd0458a",
    "url": "images/cryptocurrency-icons/sbd.svg"
  },
  {
    "revision": "ac72752e40585f5fa606036c6d0b88e5",
    "url": "images/cryptocurrency-icons/sberbank.svg"
  },
  {
    "revision": "71977ead78e116a5d394ccaddbfcd18e",
    "url": "images/cryptocurrency-icons/sc.svg"
  },
  {
    "revision": "0d11746461ef44bbf40953818df1aafc",
    "url": "images/cryptocurrency-icons/shift.svg"
  },
  {
    "revision": "038a8bbc1bb0d069e215f84ce6c5e8e3",
    "url": "images/cryptocurrency-icons/sib.svg"
  },
  {
    "revision": "862acf6058593740fe9b6d533d7cd4f6",
    "url": "images/cryptocurrency-icons/sky.svg"
  },
  {
    "revision": "32e0332eef190886458e515e3db4186d",
    "url": "images/cryptocurrency-icons/slr.svg"
  },
  {
    "revision": "7ad96241870f0d80488c7a692ae90544",
    "url": "images/cryptocurrency-icons/sls.svg"
  },
  {
    "revision": "44bf12bdb37565d96efb09ef03bb8188",
    "url": "images/cryptocurrency-icons/smart.svg"
  },
  {
    "revision": "eef73293aff505039e71333a1456f77a",
    "url": "images/cryptocurrency-icons/sngls.svg"
  },
  {
    "revision": "d40450b9accf7a19cbfc52efa76c8161",
    "url": "images/cryptocurrency-icons/snm.svg"
  },
  {
    "revision": "f9703bf5642af5dddf8cbeae14fb13fc",
    "url": "images/cryptocurrency-icons/snt.svg"
  },
  {
    "revision": "344be2dbfbd6443de311d710e24c3c47",
    "url": "images/cryptocurrency-icons/soc.svg"
  },
  {
    "revision": "0d758afadcbbe44af4f13a3be4e631c8",
    "url": "images/cryptocurrency-icons/spank.svg"
  },
  {
    "revision": "31d3deb57d5bcf1fea877126a282048a",
    "url": "images/cryptocurrency-icons/sphtx.svg"
  },
  {
    "revision": "e101b82b530d4caf7c1f6247fc1efba8",
    "url": "images/cryptocurrency-icons/srn.svg"
  },
  {
    "revision": "99882d3459ccd2c90c76119a066fa957",
    "url": "images/cryptocurrency-icons/stak.svg"
  },
  {
    "revision": "c09e1cb3ff2e0f09df42362f1560767b",
    "url": "images/cryptocurrency-icons/start.svg"
  },
  {
    "revision": "e1a29642d18fa0f1ed3888094fd0458a",
    "url": "images/cryptocurrency-icons/steem.svg"
  },
  {
    "revision": "2a9823a425ae5021d641ace70bbf2247",
    "url": "images/cryptocurrency-icons/storj.svg"
  },
  {
    "revision": "2afc6856cd34657d11194123521b83ca",
    "url": "images/cryptocurrency-icons/storm.svg"
  },
  {
    "revision": "da897b4dca2374c6b25506fc05ed9a16",
    "url": "images/cryptocurrency-icons/stq.svg"
  },
  {
    "revision": "796ce5f1cca56c848748f8057c80ac96",
    "url": "images/cryptocurrency-icons/strat.svg"
  },
  {
    "revision": "8fa36dc54beb88707adba912e51c9ca2",
    "url": "images/cryptocurrency-icons/sub.svg"
  },
  {
    "revision": "d6f8b2e7cb798ece1f86a3ccbe265eb8",
    "url": "images/cryptocurrency-icons/sumo.svg"
  },
  {
    "revision": "e7d658181cc00d85de041133ac7a194a",
    "url": "images/cryptocurrency-icons/sys.svg"
  },
  {
    "revision": "9ed693c0287a3c1965f5f393fd9349d0",
    "url": "images/cryptocurrency-icons/taas.svg"
  },
  {
    "revision": "73a19bebd01d1c5a638c2b17a4ea5ecd",
    "url": "images/cryptocurrency-icons/tau.svg"
  },
  {
    "revision": "4d1688d7b57ce317b654fa070f25241e",
    "url": "images/cryptocurrency-icons/tbx.svg"
  },
  {
    "revision": "44a0d5ea247ac3d1cf1659e0992c25b3",
    "url": "images/cryptocurrency-icons/tel.svg"
  },
  {
    "revision": "d528500efe603fa3ebc9439d954a881b",
    "url": "images/cryptocurrency-icons/ten.svg"
  },
  {
    "revision": "818364d1e6f4b7065939679cf58aee88",
    "url": "images/cryptocurrency-icons/tern.svg"
  },
  {
    "revision": "891b64b7c032f8f791ba02e0625a62b2",
    "url": "images/cryptocurrency-icons/tgch.svg"
  },
  {
    "revision": "2d314690c24e616f83492e566a8bfd2a",
    "url": "images/cryptocurrency-icons/theta.svg"
  },
  {
    "revision": "433153e914002331c2801e0aaaff777d",
    "url": "images/cryptocurrency-icons/tix.svg"
  },
  {
    "revision": "1aebf405c19472c1d85630441d6be677",
    "url": "images/cryptocurrency-icons/tkn.svg"
  },
  {
    "revision": "1564aeb7e6b602f5f4c5bfc7c6cc8b0e",
    "url": "images/cryptocurrency-icons/tks.svg"
  },
  {
    "revision": "5f6676cac92d51dbbae0ee90ebf7bd30",
    "url": "images/cryptocurrency-icons/tnb.svg"
  },
  {
    "revision": "25b37c9c293624cdca10194408a2a394",
    "url": "images/cryptocurrency-icons/tnc.svg"
  },
  {
    "revision": "eaaab90e0bd97ebec7506809cb39003f",
    "url": "images/cryptocurrency-icons/tnt.svg"
  },
  {
    "revision": "28d5804bfedc8f1d6f91ee5d3206bf04",
    "url": "images/cryptocurrency-icons/tomo.svg"
  },
  {
    "revision": "0e8712721a145b4c846c4f1d2cd88ce6",
    "url": "images/cryptocurrency-icons/tpay.svg"
  },
  {
    "revision": "d5b89aa993c5f5b9fbf9ba9f80df8061",
    "url": "images/cryptocurrency-icons/trig.svg"
  },
  {
    "revision": "5892ae1910b1f80ef897bd0cb535b761",
    "url": "images/cryptocurrency-icons/trtl.svg"
  },
  {
    "revision": "1961f3cecf0f87fbb1dbb6edc03a8e4c",
    "url": "images/cryptocurrency-icons/trx.svg"
  },
  {
    "revision": "e038173b8884dd256ba4eb0f334743d8",
    "url": "images/cryptocurrency-icons/tusd.svg"
  },
  {
    "revision": "c64b88f32ac0b077154674a38120f281",
    "url": "images/cryptocurrency-icons/tzc.svg"
  },
  {
    "revision": "3f30967bbd990e24e112646082765793",
    "url": "images/cryptocurrency-icons/ubq.svg"
  },
  {
    "revision": "2ea21b063567bf6b5101b6c58fc64bdc",
    "url": "images/cryptocurrency-icons/unity.svg"
  },
  {
    "revision": "7c06000320bc98c5a085bc61b3a99985",
    "url": "images/cryptocurrency-icons/usd.svg"
  },
  {
    "revision": "264c9c299e79380de7e7b3d2eba2fdfc",
    "url": "images/cryptocurrency-icons/usdt.svg"
  },
  {
    "revision": "0fa13b6fca9f1204928df8649a6b7b3a",
    "url": "images/cryptocurrency-icons/usdc.svg"
  },
  {
    "revision": "287ec68bf04f373305b6e524312be805",
    "url": "images/cryptocurrency-icons/utk.svg"
  },
  {
    "revision": "b5f70a4a9428e3422c49e6c70c42eaa4",
    "url": "images/cryptocurrency-icons/vet.svg"
  },
  {
    "revision": "2493b9d1a1873b3f1a3fee088cc8e25f",
    "url": "images/cryptocurrency-icons/veri.svg"
  },
  {
    "revision": "a6416945c1f9be7f2b1a668a701c763e",
    "url": "images/cryptocurrency-icons/via.svg"
  },
  {
    "revision": "409a6684474be822b34b10eeeb87fcde",
    "url": "images/cryptocurrency-icons/vib.svg"
  },
  {
    "revision": "dcd4a116fbab6dc0e473a82263fec3ea",
    "url": "images/cryptocurrency-icons/vibe.svg"
  },
  {
    "revision": "27efc2bf7772d803d6fa6f042feea2f3",
    "url": "images/cryptocurrency-icons/vivo.svg"
  },
  {
    "revision": "929c7170e30fde5fb38acd07a8454293",
    "url": "images/cryptocurrency-icons/vrc.svg"
  },
  {
    "revision": "9111037206e1dd9c1554910d2e5a3df9",
    "url": "images/cryptocurrency-icons/vrsc.svg"
  },
  {
    "revision": "c9e6a97ae4497cf1e298699ac8a57703",
    "url": "images/cryptocurrency-icons/vtc.svg"
  },
  {
    "revision": "855c6b41d047a22da69b9ca3f20757e5",
    "url": "images/cryptocurrency-icons/wabi.svg"
  },
  {
    "revision": "f87333554a873b6f846fc334c91fc5ef",
    "url": "images/cryptocurrency-icons/wan.svg"
  },
  {
    "revision": "9cf6b26547b0cda6c603a0b5e02188f9",
    "url": "images/cryptocurrency-icons/waves.svg"
  },
  {
    "revision": "fa5d030cc6e96146080c07ef2b871b90",
    "url": "images/cryptocurrency-icons/wax.svg"
  },
  {
    "revision": "0d49835b5cbe6971ee67944ab94bd6e3",
    "url": "images/cryptocurrency-icons/wgr.svg"
  },
  {
    "revision": "28a60ed9684c6589a696384b6b2b1721",
    "url": "images/cryptocurrency-icons/wicc.svg"
  },
  {
    "revision": "155eba6953d9844e9842b56554cb3114",
    "url": "images/cryptocurrency-icons/wings.svg"
  },
  {
    "revision": "7f97fd769cd45febd9f8b9312fcfcf26",
    "url": "images/cryptocurrency-icons/wpr.svg"
  },
  {
    "revision": "754b9b586a57a7dfba2a21609d72064d",
    "url": "images/cryptocurrency-icons/wtc.svg"
  },
  {
    "revision": "1130c6bf35af1550d762d5e07d55d185",
    "url": "images/cryptocurrency-icons/xas.svg"
  },
  {
    "revision": "ab1c19f90f8e8a26acf1806dcdb5af91",
    "url": "images/cryptocurrency-icons/x.svg"
  },
  {
    "revision": "3a1e883035ce85dea9ba7a1d0378b73b",
    "url": "images/cryptocurrency-icons/xcp.svg"
  },
  {
    "revision": "7436177966f1300f63efe5a63f3c69c0",
    "url": "images/cryptocurrency-icons/xbc.svg"
  },
  {
    "revision": "b9f846a7c88fffbf8ab7b98386aa05c4",
    "url": "images/cryptocurrency-icons/xby.svg"
  },
  {
    "revision": "2451454686df3bd18e1cda32e4c31d34",
    "url": "images/cryptocurrency-icons/xdn.svg"
  },
  {
    "revision": "8d21fb55b4b09203cb0c41d7aedebe65",
    "url": "images/cryptocurrency-icons/xin.svg"
  },
  {
    "revision": "f95b2123bf07eb2a5d2cdbd08e0798f2",
    "url": "images/cryptocurrency-icons/xem.svg"
  },
  {
    "revision": "3705ca1f8293dc30feec3f173429de2b",
    "url": "images/cryptocurrency-icons/xlm.svg"
  },
  {
    "revision": "b030c030d9261176721aae37eb8a02b7",
    "url": "images/cryptocurrency-icons/xmcc.svg"
  },
  {
    "revision": "1d16ef2b676a0372942fe1cee4e79d6f",
    "url": "images/cryptocurrency-icons/xmg.svg"
  },
  {
    "revision": "a6165b9795a92cbe5465c262d6d4202b",
    "url": "images/cryptocurrency-icons/xmo.svg"
  },
  {
    "revision": "c43edff240287eb35c61c40952ffec39",
    "url": "images/cryptocurrency-icons/xmr.svg"
  },
  {
    "revision": "da6929691c1e6d8eb54192141777e916",
    "url": "images/cryptocurrency-icons/xmy.svg"
  },
  {
    "revision": "ed9a9cbfd3ff0f89cd82a1c59cecf160",
    "url": "images/cryptocurrency-icons/xp.svg"
  },
  {
    "revision": "23ce1f2cd678036abd4fc41327fd9324",
    "url": "images/cryptocurrency-icons/xpa.svg"
  },
  {
    "revision": "9d4f723831235ea08dd07c40f4c02b5a",
    "url": "images/cryptocurrency-icons/xpm.svg"
  },
  {
    "revision": "eeead9b539eb7c78652ab8520fbd1fb2",
    "url": "images/cryptocurrency-icons/xrp.svg"
  },
  {
    "revision": "1ff3b7edb1a0f340281388867026f29b",
    "url": "images/cryptocurrency-icons/xsg.svg"
  },
  {
    "revision": "bcb17d4d7aac6a17bba521b918fdd8ad",
    "url": "images/cryptocurrency-icons/xtz.svg"
  },
  {
    "revision": "5ba7c86c97fdbdd3445c0d6efe854901",
    "url": "images/cryptocurrency-icons/xvc.svg"
  },
  {
    "revision": "e5ae3b33819018ad3c2ca16d51a194b8",
    "url": "images/cryptocurrency-icons/xuc.svg"
  },
  {
    "revision": "18af8128e2fa3b84d53eec962467746d",
    "url": "images/cryptocurrency-icons/xvg.svg"
  },
  {
    "revision": "e6011896643b9ca0e51d1ecd27c847eb",
    "url": "images/cryptocurrency-icons/xzc.svg"
  },
  {
    "revision": "50f61e7b885c233cdb1db2ec5634f3b5",
    "url": "images/cryptocurrency-icons/yoyow.svg"
  },
  {
    "revision": "fd63561799bacff865b5ec9c8c3555fb",
    "url": "images/cryptocurrency-icons/zcl.svg"
  },
  {
    "revision": "608d9d7728a3de476da175f8cfb7449b",
    "url": "images/browser-logos/opera/opera.svg"
  },
  {
    "revision": "4e5e285ef3e063e0fdedd9ab6d9383c8",
    "url": "images/browser-logos/firefox/firefox.svg"
  },
  {
    "revision": "33605cda759b26a115fa40bf6fa0648b",
    "url": "images/browser-logos/chrome/chrome.svg"
  },
  {
    "revision": "1f215e0f4a11add13d704b3a2223cf4c",
    "url": "images/background.svg"
  },
  {
    "url": "gestures.29a31d3896ae7e07ea8d.js"
  },
  {
    "url": "app.296edd30b298a0aecbd5.js"
  },
  {
    "url": "3box.1e964449616beff33a27.js"
  }
];